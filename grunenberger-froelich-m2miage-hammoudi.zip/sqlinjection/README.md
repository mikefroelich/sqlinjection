# sqlinjection
M2 MIAGE - Sécurité des applications
Projet Sécurité Formulaires
Céline Grunenberger
Mike Froelich

Travail attendu : 
- un formulaire non sécurisé 
- un formulaire sécurisé 
- Mettre en évidence les 2 failles vues en cours 3 nouvelles failles :
- XSS 
- une autre faille SQL
- une autre faille SQL

Informations sur le projet :
Deadline projet : Dimanche 17 Septembre 
Soutenance orale (10min) : Lundi 18 Septembre
