<footer>
	<p>
		<a href="formulaireNonSecurise.php"> Formulaire non sécurisé </a> 
	<br/>
		<a href="formulaireSecurise.php"> Formulaire sécurisé </a>
	</p>
</footer>